import axios from 'axios';

export default axios.create({
	baseURL: 'https://api.unsplash.com',
	headers: {
		Authorization: 'Client-ID 3bc628900421979b19ab1e4da7378d787cd18abfd82115aaaab6c8f0db14e814'
	}
});