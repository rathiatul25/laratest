import React,{Component} from 'react';
import PostList from './PostList';

class App extends React.Component {
	
	render(){
		return (

			<div>
				<PostList />
			</div>

		)		
	}
}

export default App;


