import React from 'react';

class GoogleAuth extends React.Component {
	componentDidMount(){
		window.gapi.load('client:auth2', () => {
			window.gapi.client.init({
				clientId:'772580349912-qg6vgvaij74s3gfu7g0jkaffmvsoaeqa.apps.googleusercontent.com',
				scope: 'email'
			});
		});
	}

	render() {
		return (
			<div>google</div>
		)
	}
}

export default GoogleAuth;