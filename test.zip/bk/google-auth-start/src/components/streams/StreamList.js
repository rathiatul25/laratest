import React from 'react';

const StreamList = () => {
	return <div>StreamList</div>
};

export default StreamList;