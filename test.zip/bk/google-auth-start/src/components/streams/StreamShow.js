import React from 'react';

const StreamShow = () => {
	return <div>StreamShow</div>
};

export default StreamShow;