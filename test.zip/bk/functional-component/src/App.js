import React,{Component} from 'react';
//import logo from './logo.svg';
import './App.css';
import CommentDetail from './CommentDetail';
import ApprovalCard from './ApprovalCard';
import faker from 'faker';
// default function() {
  
  
//     return (
//         <div>hii</div>
//     )
  
// }


export default class App extends Component {

	render(){
		
		return (
			<div>
				<ApprovalCard>
					<div>
						Are you sure? you want to do this?
					</div>
				</ApprovalCard>
				<ApprovalCard>
					<CommentDetail author='atul' profile={faker.image.avatar()} />
				</ApprovalCard>
				
				<ApprovalCard>
					<CommentDetail author='admin' profile={faker.image.avatar()} />
				</ApprovalCard>
				
				<ApprovalCard>
					<CommentDetail author='test' profile={faker.image.avatar()} />
				</ApprovalCard>
			</div>
		)
	}
}
//Pass one component as a props into another component, and it will appear as a children


