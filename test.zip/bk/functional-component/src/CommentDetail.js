import React from 'react';

const CommentDetail = (props) => {
	console.log(props)
	return (
		<div>
			<a href='/'>
			 <img alt='avatar' src={props.profile}/>	
			</a>
			<div className='content'>
				{props.author}
			</div>
		</div>
	)
}

export default CommentDetail