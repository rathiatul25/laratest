import React from 'react';

const ApprovalCard = (props) => {
	console.log(props)
	return (
		<div>
			{props.children}
			<button>Accept</button>
			<button>Reject</button>
		</div>
	)
}

export default ApprovalCard