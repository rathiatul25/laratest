import React,{Component} from 'react';
import logo from './logo.svg';
import './App.css';

// default function() {
  
  
//     return (
//         <div>hii</div>
//     )
  
// }

function getButtonText()
{
	return 'Click me';
}
export default class App extends Component {

	render(){
		const style = {backgroundColor: 'blue', color: 'white'}
		const buttonName = "click me"
		return (
			<div>
				<label className='label' htmlFor='name'>Name</label>
				<button style={{backgroundColor: 'blue', color: 'white'}}>{buttonName}</button>
				<button style={style}>{getButtonText()}</button>
			</div>
		)
	}
}



