import { combineReducers } from 'redux';

const songReducer = () => {
	return [
		{title: 'song 1', duration: '1:30'},
		{title: 'song 2', duration: '2:30'},
		{title: 'song 3', duration: '3:30'},		
	];
};

const selectedSongReducer = (selectedSong = null, action) => {
	
	if (action.type == 'SONG_SELECTED') {
		return action.payload;
	}
	return selectedSong
}

export default combineReducers({
	songs:songReducer,
	selectedSong:selectedSongReducer
})